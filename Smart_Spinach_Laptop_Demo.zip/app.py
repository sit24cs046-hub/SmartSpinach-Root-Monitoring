
import math
import random
from datetime import datetime

import cv2
import numpy as np
import streamlit as st

st.set_page_config(
    page_title="Smart Spinach Root Monitoring",
    page_icon="🌱",
    layout="wide"
)

# -----------------------------
# Session state
# -----------------------------
if "tick" not in st.session_state:
    st.session_state.tick = 0

if "scenario" not in st.session_state:
    st.session_state.scenario = "Normal"

if "history" not in st.session_state:
    st.session_state.history = []

# -----------------------------
# Helpers
# -----------------------------
def get_demo_values(tick, scenario):
    # These values are SIMULATED because ESP32/sensors are not connected yet.
    t = 22.0 + 0.5 * math.sin(tick / 3) + random.uniform(-0.08, 0.08)
    ph = 6.0 + 0.05 * math.sin(tick / 4) + random.uniform(-0.01, 0.01)
    ec = 2.05 + 0.06 * math.sin(tick / 5) + random.uniform(-0.02, 0.02)
    do = 6.2 + 0.15 * math.sin(tick / 3.5) + random.uniform(-0.05, 0.05)
    level = 80 + 2 * math.sin(tick / 4) + random.uniform(-1, 1)

    if scenario == "High Temperature":
        t = 27.0 + random.uniform(-0.3, 0.3)
    elif scenario == "Low Dissolved Oxygen":
        do = 3.8 + random.uniform(-0.2, 0.2)
    elif scenario == "Abnormal pH":
        ph = 7.1 + random.uniform(-0.08, 0.08)
    elif scenario == "High EC":
        ec = 2.8 + random.uniform(-0.08, 0.08)
    elif scenario == "Low Water Level":
        level = 20 + random.uniform(-2, 2)

    return {
        "Temperature": round(t, 2),
        "pH": round(ph, 2),
        "EC": round(ec, 2),
        "DO": round(do, 2),
        "Water Level": round(level, 1),
    }

def sensor_status(v):
    alerts = []
    if v["Temperature"] > 24:
        alerts.append("High water temperature")
    if v["Temperature"] < 18:
        alerts.append("Low water temperature")
    if not 5.5 <= v["pH"] <= 6.5:
        alerts.append("Abnormal pH")
    if not 1.8 <= v["EC"] <= 2.3:
        alerts.append("Abnormal EC")
    if v["DO"] < 5:
        alerts.append("Low dissolved oxygen")
    if v["Water Level"] < 30:
        alerts.append("Low water level")
    return alerts

def analyze_root_image(file_bytes):
    data = np.frombuffer(file_bytes, np.uint8)
    image = cv2.imdecode(data, cv2.IMREAD_COLOR)
    if image is None:
        return None, None

    # Resize for quick processing.
    image = cv2.resize(image, (900, int(image.shape[0] * 900 / image.shape[1])))
    hsv = cv2.cvtColor(image, cv2.COLOR_BGR2HSV)

    # Heuristic color masks for demonstration.
    # This is a prototype, not a medical/plant-disease diagnostic model.
    h, s, val = cv2.split(hsv)

    white = ((s < 70) & (val > 145))
    brown = ((h >= 5) & (h <= 25) & (s >= 55) & (val >= 35) & (val <= 210))
    black = ((val < 65) & (s > 25))

    # Ignore a small border to reduce edge/background effects.
    border = 12
    roi = np.zeros_like(white, dtype=bool)
    roi[border:-border, border:-border] = True

    total = int(np.count_nonzero(roi))
    white_n = int(np.count_nonzero(white & roi))
    brown_n = int(np.count_nonzero(brown & roi))
    black_n = int(np.count_nonzero(black & roi))

    if total == 0:
        return image, {"white": 0, "brown": 0, "black": 0, "status": "No image area"}

    white_pct = 100 * white_n / total
    brown_pct = 100 * brown_n / total
    black_pct = 100 * black_n / total

    # Demo classification: brown/black dominance means risk.
    if black_pct > 8 or brown_pct > 18:
        status = "ROOT ROT RISK"
    elif brown_pct > 8:
        status = "WARNING"
    else:
        status = "HEALTHY / LOW RISK"

    overlay = image.copy()
    risk_mask = ((brown | black) & roi).astype(np.uint8) * 255
    contours, _ = cv2.findContours(risk_mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    cv2.drawContours(overlay, contours, -1, (0, 0, 255), 2)

    return overlay, {
        "white": round(white_pct, 1),
        "brown": round(brown_pct, 1),
        "black": round(black_pct, 1),
        "status": status,
    }

# -----------------------------
# Header
# -----------------------------
st.title("🌱 Smart Spinach Root Monitoring")
st.caption("Hydroponic monitoring + digital image processing + IoT alert prototype")

st.info(
    "LAPTOP DEMO MODE: sensor values below are simulated because the ESP32 and physical sensors "
    "are not connected yet. The image-processing section uses OpenCV on an uploaded root image."
)

# -----------------------------
# Sidebar
# -----------------------------
with st.sidebar:
    st.header("Demo Controls")
    scenario = st.selectbox(
        "Sensor scenario",
        [
            "Normal",
            "High Temperature",
            "Low Dissolved Oxygen",
            "Abnormal pH",
            "High EC",
            "Low Water Level",
        ],
        index=[
            "Normal",
            "High Temperature",
            "Low Dissolved Oxygen",
            "Abnormal pH",
            "High EC",
            "Low Water Level",
        ].index(st.session_state.scenario),
    )
    st.session_state.scenario = scenario

    st.markdown("### Planned real system")
    st.write("ESP32 → Arduino IDE program → WiFi → Blynk")
    st.write("Camera → Python/OpenCV → Root analysis → Alert")

    if st.button("Reset demo"):
        st.session_state.tick = 0
        st.session_state.history = []
        st.rerun()

# -----------------------------
# Live sensor section
# -----------------------------
st.subheader("📡 Live Hydroponic Readings")

@st.fragment(run_every="2s")
def live_readings():
    st.session_state.tick += 1
    values = get_demo_values(st.session_state.tick, st.session_state.scenario)
    alerts = sensor_status(values)

    cols = st.columns(5)
    cols[0].metric("Water Temperature", f'{values["Temperature"]} °C')
    cols[1].metric("pH", f'{values["pH"]}')
    cols[2].metric("EC", f'{values["EC"]} mS/cm')
    cols[3].metric("Dissolved Oxygen", f'{values["DO"]} mg/L')
    cols[4].metric("Water Level", f'{values["Water Level"]} %')

    if alerts:
        st.error("⚠️ SENSOR ALERT: " + " | ".join(alerts))
    else:
        st.success("✅ Sensor conditions are currently within the demo safe range.")

    now = datetime.now().strftime("%H:%M:%S")
    st.caption(f"Last updated: {now} | Demo scenario: {st.session_state.scenario}")

    st.session_state.history.append({
        "Time": now,
        "Temperature": values["Temperature"],
        "pH": values["pH"],
        "EC": values["EC"],
        "DO": values["DO"],
    })
    st.session_state.history = st.session_state.history[-30:]

live_readings()

# -----------------------------
# Image processing
# -----------------------------
st.subheader("📷 Digital Image Processing")

uploaded = st.file_uploader(
    "Upload a root image for the demo",
    type=["jpg", "jpeg", "png"],
)

if uploaded is not None:
    result_image, result = analyze_root_image(uploaded.getvalue())
    if result is not None:
        left, right = st.columns(2)
        with left:
            st.image(result_image, caption="OpenCV analysis overlay", use_container_width=True)
        with right:
            st.metric("White area", f'{result["white"]}%')
            st.metric("Brown area", f'{result["brown"]}%')
            st.metric("Black area", f'{result["black"]}%')

            if result["status"] == "ROOT ROT RISK":
                st.error("🚨 ROOT ROT RISK DETECTED")
            elif result["status"] == "WARNING":
                st.warning("⚠️ ROOT DISCOLORATION WARNING")
            else:
                st.success("✅ HEALTHY / LOW RISK")

            st.caption(
                "Prototype rule-based color analysis. In the final system, a fixed camera will "
                "continuously capture the root area and this module will analyze those frames."
            )
else:
    st.warning("Upload a root image to demonstrate the image-processing module.")

# -----------------------------
# Combined decision
# -----------------------------
st.subheader("🧠 Combined Root-Rot Decision")

sensor_demo = get_demo_values(st.session_state.tick, st.session_state.scenario)
sensor_alerts = sensor_status(sensor_demo)

image_alert = False
if uploaded is not None:
    _, image_result = analyze_root_image(uploaded.getvalue())
    image_alert = image_result and image_result["status"] in ("ROOT ROT RISK", "WARNING")

if sensor_alerts or image_alert:
    st.error(
        "🚨 ROOT ROT RISK / WARNING — Corrective action is required. "
        "Check water conditions and inspect the roots."
    )
else:
    st.success("🟢 CURRENT STATUS: No root-rot risk detected by the demo rules.")

# -----------------------------
# History chart
# -----------------------------
if st.session_state.history:
    st.subheader("📈 Recent Readings")
    st.line_chart(
        {
            "Temperature (°C)": [x["Temperature"] for x in st.session_state.history],
            "pH": [x["pH"] for x in st.session_state.history],
            "EC (mS/cm)": [x["EC"] for x in st.session_state.history],
            "DO (mg/L)": [x["DO"] for x in st.session_state.history],
        }
    )

st.divider()
st.caption(
    "Project basis: Smart Spinach Root Monitoring — sensors monitor pH, temperature, DO, EC and "
    "nutrient-solution conditions; camera-based digital image processing monitors root color and "
    "structural changes; IoT provides mobile/web alerts."
)
