SMART SPINACH ROOT MONITORING — LAPTOP DEMO

1. Open Command Prompt in this folder.
2. Install Streamlit:
   pip install -r requirements.txt

3. Run:
   streamlit run app.py

4. The browser dashboard will open.
5. Choose a sensor scenario from the left side to demonstrate changing readings.
6. Upload a root image to demonstrate OpenCV color analysis.

IMPORTANT:
This is a laptop prototype. Sensor readings are simulated because ESP32/sensors are not connected.
The image module is a rule-based OpenCV prototype, not a validated plant-disease diagnostic system.

FINAL HARDWARE ARCHITECTURE:
Sensors -> ESP32 -> Arduino program -> WiFi -> Blynk -> Mobile alert
Camera -> Image-processing computer -> Root analysis -> Blynk/mobile alert
